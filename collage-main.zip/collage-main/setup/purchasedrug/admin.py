from django.contrib import admin
from .models import PurchaseDrug
# Register your models here.
admin.site.register(PurchaseDrug)
