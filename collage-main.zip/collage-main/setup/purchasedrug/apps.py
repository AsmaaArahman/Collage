from django.apps import AppConfig


class PurchasedrugConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'purchasedrug'
