from django.contrib import admin
from .models import Dispensing,SoldDrug
# Register your models here.


admin.site.register(Dispensing)
admin.site.register(SoldDrug)