from django.contrib import admin
from . import models

# Register your models here.
admin.site.register(models.RequestDrug)
admin.site.register(models.StoreRequest)
